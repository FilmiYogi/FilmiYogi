# FilmiYogi

A responsive, dark movie-review website starter.

## Files
- index.html
- style.css
- script.js

## Run locally
Open `index.html` in a browser.

## Put it online
Upload these three files to a static hosting service such as GitHub Pages, Netlify, or Vercel.

## Customize
Edit the `movies` array in `script.js` to add your own movie titles, ratings, genres and spoiler-free reviews.
