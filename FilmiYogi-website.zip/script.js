const movies=[
 {title:"Mirzapur: The Final Chapter",year:"2026",genre:"Crime • Drama",rating:"8.7",quality:"Review",tags:["favorite","imdb"],review:"A gripping, intense watch with strong performances. No-spoiler verdict: worth your time."},
 {title:"The Last Journey",year:"2026",genre:"Drama • Thriller",rating:"8.4",quality:"Review",tags:["imdb"],review:"A slow-burn story that rewards patience with atmosphere and emotion."},
 {title:"City of Dreams",year:"2026",genre:"Romance • Drama",rating:"7.9",quality:"Review",tags:["favorite"],review:"Stylish, emotional and easy to watch when you want a lighter movie night."},
 {title:"Shadow Protocol",year:"2026",genre:"Action • Thriller",rating:"8.1",quality:"Review",tags:["imdb"],review:"Fast-paced action with enough twists to keep the screen interesting."},
 {title:"Raat Ke Raaz",year:"2026",genre:"Mystery • Horror",rating:"7.8",quality:"Review",tags:["favorite"],review:"Atmospheric mystery with a strong first half and an intriguing setup."},
 {title:"Beyond The Stars",year:"2026",genre:"Sci-Fi • Adventure",rating:"8.3",quality:"Review",tags:["imdb"],review:"Big ideas, beautiful visuals and an entertaining journey for sci-fi fans."},
 {title:"Dil Se Again",year:"2026",genre:"Romance",rating:"7.6",quality:"Review",tags:["favorite"],review:"A warm, feel-good romance with memorable music and charming chemistry."},
 {title:"Black File",year:"2026",genre:"Crime • Mystery",rating:"8.0",quality:"Review",tags:["imdb"],review:"A clever crime mystery that keeps you guessing without overcomplicating things."}
];
let filter="all";
const grid=document.querySelector("#movieGrid"), search=document.querySelector("#search");
function render(){
 const q=search.value.toLowerCase();
 const list=movies.filter(m=>(filter==="all"||m.tags.includes(filter))&&m.title.toLowerCase().includes(q));
 grid.innerHTML=list.map(m=>`<article class="card"><div class="poster"><span class="quality">${m.quality}</span><h3>${m.title}</h3></div><div class="info"><div class="meta">${m.year} • ${m.genre}</div><div class="rating">★ ${m.rating}/10</div><p class="review">${m.review}</p></div></article>`).join("")||"<p>No movies found.</p>";
}
document.querySelectorAll(".chip").forEach(b=>b.onclick=()=>{document.querySelectorAll(".chip").forEach(x=>x.classList.remove("active"));b.classList.add("active");filter=b.dataset.filter;render()});
search.addEventListener("input",render);render();
